import Caller from './Caller.services';

const ScanService = {
    /**
     * Scanner le QR code d'un client (PRESTATAIRE)
     * @param {string} qrCode - QR code du client
     * @param {number} promotionId - ID de la promotion
     * @param {number} prestataireId - ID du prestataire (optionnel si une seule fiche)
     */
    scan: async (qrCode, promotionId, prestataireId = null) => {
        try {
            const data = { qrCode, promotionId };
            if (prestataireId) data.prestataireId = prestataireId;
            
            const response = await Caller.post('/scans/scan', data);
            return response.data;
        } catch (error) {
            throw error.response?.data || { success: false, message: 'Erreur lors du scan' };
        }
    },

    /**
     * Récupérer mes promotions actives (PRESTATAIRE)
     * Filtre côté client pour ne garder que les promos valides
     * @param {number} prestataireId - ID du prestataire
     */
    getMyActivePromotions: async (prestataireId) => {
        try {
            const url = prestataireId 
                ? `/promotions/me?prestataireId=${prestataireId}`
                : '/promotions/me';
            const response = await Caller.get(url);
            
            if (response.data.success && response.data.data) {
                const now = new Date();
                // Filtrer les promotions actives et dans les dates
                const activePromos = response.data.data.filter(promo => {
                    const dateDebut = new Date(promo.dateDebut);
                    const dateFin = new Date(promo.dateFin);
                    return promo.estActive && dateDebut <= now && dateFin >= now;
                });
                return { success: true, data: activePromos };
            }
            return response.data;
        } catch (error) {
            console.error('Erreur getMyActivePromotions:', error);
            return { success: false, data: [], message: 'Erreur lors de la récupération' };
        }
    },

    /**
     * Récupérer mes promotions (PRESTATAIRE) - toutes
     */
    getMyPromotions: async (prestataireId = null) => {
        try {
            const url = prestataireId 
                ? `/promotions/me?prestataireId=${prestataireId}`
                : '/promotions/me';
            const response = await Caller.get(url);
            return response.data;
        } catch (error) {
            throw error.response?.data || { success: false, message: 'Erreur lors de la récupération' };
        }
    },

    /**
     * Historique des scans (PRESTATAIRE)
     * @param {number} prestataireId - ID du prestataire (optionnel)
     * @param {number} page - Page
     * @param {number} limit - Limite par page
     */
    getHistory: async (prestataireId = null, page = 1, limit = 20) => {
        try {
            const params = new URLSearchParams();
            params.append('page', page);
            params.append('limit', limit);
            if (prestataireId) params.append('prestataireId', prestataireId);
            
            const response = await Caller.get(`/scans/history?${params.toString()}`);
            return response.data;
        } catch (error) {
            throw error.response?.data || { success: false, message: 'Erreur lors de la récupération' };
        }
    },

    /**
     * Mes scans (CLIENT)
     */
    getMyScans: async (page = 1, limit = 20) => {
        try {
            const response = await Caller.get(`/scans/me?page=${page}&limit=${limit}`);
            return response.data;
        } catch (error) {
            throw error.response?.data || { success: false, message: 'Erreur lors de la récupération' };
        }
    },

    /**
     * Statistiques de mes scans (CLIENT)
     */
    getMyStats: async () => {
        try {
            const response = await Caller.get('/scans/me/stats');
            return response.data;
        } catch (error) {
            throw error.response?.data || { success: false, message: 'Erreur lors de la récupération' };
        }
    }
};

export default ScanService;
